﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebsiteBanSach.Models;

namespace WebsiteBanSach.Controllers
{
    public class SachController : Controller
    {
        QuanLyBanSachContext db = new QuanLyBanSachContext();
        // GET: Sach
//Sach moi
        public PartialViewResult SachMoiPartial()
        {
            var book = db.Saches.Take(3).ToList();
            return PartialView(book);
        }
        public ViewResult XemChiTiet(int id=0)
        {
            var book = db.Saches.Find(id);
            //var sach = db.Saches.FirstOrDefault(x => x.MaSach == id);
            if (book == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            return View(book);
        }
    }
}