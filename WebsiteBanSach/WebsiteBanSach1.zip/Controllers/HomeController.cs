﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebsiteBanSach.Models;
using PagedList;
using PagedList.Mvc;
namespace WebsiteBanSach.Controllers
{
    public class HomeController : Controller
    {
        QuanLyBanSachContext db = new QuanLyBanSachContext();
        // GET: Home
        public ActionResult Index(int? page)
        {
            //Tao bien' so san pham tren trang
            int pageSize = 9;
            //Tao bien so trang
            int pageNumber = (page ?? 1);
            var book = db.Saches.ToList().Where(x => x.Moi == 1).OrderBy(x=>x.GiaBan).ToPagedList(pageNumber, pageSize);
            return View(book);
        }
        [HttpPost]
        public ViewResult KetQuaTimKiem(int? page, FormCollection f)
        {
            string TuKhoa = f["txtSearch"].ToString();
            List<Sach> kq = db.Saches.Where(x => x.TenSach.Contains(TuKhoa)).ToList();
            // Phan trang tim kiem
            int pageNumber = (page ?? 1);
            int pageSize = 9;
            if (kq.Count == 0)
            {
                ViewBag.Tim = "Không tìm thấy sách nào";
                return View(db.Saches.OrderBy(x=>x.TenSach).ToPagedList(pageNumber, pageSize));
            }
            return View(kq.OrderBy(x=>x.TenSach).ToPagedList(pageNumber,pageSize));
        }
    }
}