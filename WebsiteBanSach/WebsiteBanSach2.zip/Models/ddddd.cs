using System;
using System.Collections.Generic;

namespace WebsiteBanSach.Models
{
    public partial class ddddd
    {
        public System.DateTime da { get; set; }
        public string d { get; set; }
    }
}
