using System;
using System.Collections.Generic;

namespace WebsiteBanSach.Models
{
    public partial class tabletest
    {
        public string jhagsd { get; set; }
        public string asdad { get; set; }
    }
}
