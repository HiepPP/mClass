using System;
using System.Collections.Generic;

namespace WebsiteBanSach.Models
{
    public partial class dsadsa
    {
        public string dsa { get; set; }
        public string dsads { get; set; }
    }
}
