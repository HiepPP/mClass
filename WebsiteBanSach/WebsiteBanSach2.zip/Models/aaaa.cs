using System;
using System.Collections.Generic;

namespace WebsiteBanSach.Models
{
    public partial class aaaa
    {
        public string dsa { get; set; }
        public string aaaa1 { get; set; }
    }
}
